package com.cts.insurance.entities;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Customer {
private String name;
private Date DOB;
private List<Address> address;
@Autowired
@Qualifier("card1")
private AadharCard card;
public AadharCard getCard() {
	return card;
}
public void setCard(AadharCard card) {
	this.card = card;
}
public List<Address> getAddress() {
	return address;
}
public void setAddress(List<Address> address) {
	this.address = address;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Date getDOB() {
	return DOB;
}
public void setDOB(Date dOB) {
	DOB = dOB;
}
}
