package com.cts.insurance.interfaces;

public interface Insurance {

	String message(String name); 
}
