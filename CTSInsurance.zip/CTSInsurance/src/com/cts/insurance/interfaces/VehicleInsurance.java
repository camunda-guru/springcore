package com.cts.insurance.interfaces;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Component
@Lazy
public class VehicleInsurance implements Insurance {

	@Override
	public String message(String name) {
		// TODO Auto-generated method stub
		return "Vehicle Insurance for the user"+name+"done!";
	}

}
