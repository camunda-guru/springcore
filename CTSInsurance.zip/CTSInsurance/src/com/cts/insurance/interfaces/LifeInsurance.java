package com.cts.insurance.interfaces;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class LifeInsurance implements Insurance{

	@Override
	public String message(String name) {
		// TODO Auto-generated method stub
		return "Hi!"+name+"you got a 1 crore coverage";
	}

}
