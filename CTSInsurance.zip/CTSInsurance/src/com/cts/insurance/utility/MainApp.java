package com.cts.insurance.utility;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cts.insurance.entities.Address;
import com.cts.insurance.entities.Customer;
import com.cts.insurance.entities.Vehicle;
import com.cts.insurance.interfaces.Insurance;
import com.cts.insurance.interfaces.Test;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Resource resource = new ClassPathResource("spring.xml");
	       BeanFactory bean = new XmlBeanFactory(resource);
	     //  Insurance ins=   (Insurance) bean.getBean("vehicleobj") ; 
	    //   System.out.println(ins.message("Parameswari"));
	    //   ins=   (Insurance) bean.getBean("lifeobj") ; 
	    //   System.out.println(ins.message("Parameswari"));
	       
	      AbstractApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
	       Customer cust= (Customer) ctx.getBean("customer");
	       System.out.println(cust.getName());
	       System.out.println(cust.getDOB().toLocaleString());
	       for(Address addr : cust.getAddress())
	       {
	    	   System.out.println(addr.getCity());
	       }
	       System.out.println(cust.getCard().getCardNo());
	       
	       Vehicle vehicle =(Vehicle) ctx.getBean("vehicle");
	       System.out.println(vehicle.getRegNo());
	      ctx.registerShutdownHook();
	       Test test = (Test) ctx.getBean("test");
	      System.out.println( test.getIns().message("Parameswari"));
	       
	}

}
